import json
from pathlib import Path
import time
from validation.linear_modal.runner import compare,file_digest,run_one,save_json
from validation.linear_modal.reference import analyze
from validation.linear_modal.reports import write_reports

here=Path('validation/linear_modal').resolve()
manifest=json.loads((here/'manifest.json').read_text(encoding='utf-8'))
record=next(r for r in manifest if r['id']=='084_two_story_frame_v4')
path=here/record['mf_file']
snapshot=Path(r'C:\Users\Ahmed\Documents\Codex\2026-11-03\go-to-e-metufire-opencivil-from\outputs\linear_modal_validation\cases\084_two_story_frame_v4\084_two_story_frame_v4.mf')
assert json.loads(path.read_text(encoding='utf-8'))==json.loads(snapshot.read_text(encoding='utf-8'))
previous=json.loads((path.parent/'execution.json').read_text(encoding='utf-8'))
case={**record,'mf_path':path,'directory':path.parent,'model':json.loads(path.read_text(encoding='utf-8'))}
before=file_digest(path)
started=time.time()
execution=run_one(case,90)
execution['format_only_refresh']={'previous_model_sha256':previous['model_sha256'],
                                'reason':'JSON model unchanged; serialization bytes differed from saved run'}
save_json(path.parent/'execution.json',execution)
ref=analyze(case['model'],spec=record['spec'])
result=compare(case,ref)
assert result['static']['passed'] and result['modal']['passed'],result
assert before==file_digest(path),'The input model must remain untouched'
save_json(path.parent/'comparison.json',result)
summary=json.loads((here/'summary.json').read_text(encoding='utf-8'))
results=[result if r['id']==record['id'] else r for r in summary['cases']]
write_reports(here,results,summary['elapsed_seconds']+time.time()-started)
history=json.loads((here/'run_history.json').read_text(encoding='utf-8'))
history['format_only_refresh']={'case':record['id'],'static_pass':True,'modal_pass':True,
                              'input_model_unchanged':True,'input_json_equal_to_original_verified_model':True}
save_json(here/'run_history.json',history)
print('Formatting-only cached-case refresh: static/modal PASS; original input untouched.')
