import json
from pathlib import Path
from validation.linear_modal.runner import compare,save_json
from validation.linear_modal_150.reference import analyze

here=Path('validation/linear_modal_150').resolve()
manifest=json.loads((here/'manifest.json').read_text(encoding='utf-8'))
results=[]
for record in manifest:
    path=here/record['mf_file']
    if not (path.parent/'execution.json').exists():
        continue
    raw=json.loads(path.read_text(encoding='utf-8'))
    case={**record,'mf_path':path,'directory':path.parent,'model':raw}
    result=compare(case,analyze(raw,spec=record.get('spec')))
    results.append(result)
    if not result['static']['passed'] or not result['modal']['passed']:
        print(record['id'],{kind:result[kind].get('error',[c['name'] for c in result[kind].get('checks',[]) if not c['passed']])
                             for kind in ('static','modal') if not result[kind]['passed']})
print('Completed',len(results),'static pass',sum(r['static']['passed'] for r in results),'modal pass',sum(r['modal']['passed'] for r in results))
save_json(here/'work'/'partial_comparisons.json',results)
