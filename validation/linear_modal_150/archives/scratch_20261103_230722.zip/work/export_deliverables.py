from html.parser import HTMLParser
import json
from pathlib import Path
import shutil
import zipfile

from validation.linear_modal.runner import file_digest,save_json,solver_digest

root=Path('validation').resolve()
source=root/'linear_modal_150'
output=Path(r'C:\Users\Ahmed\Documents\Codex\2026-11-03\go-to-e-metufire-opencivil-from\outputs')
output.mkdir(parents=True,exist_ok=True)
snapshot=output/'linear_modal_150_validation'
snapshot.mkdir(parents=True,exist_ok=True)
summaries=[]
for directory in ('linear_modal','linear_modal_150'):
    here=root/directory
    summary=json.loads((here/'summary.json').read_text(encoding='utf-8'))
    manifest=json.loads((here/'manifest.json').read_text(encoding='utf-8'))
    assert len(manifest)==summary['model_count']
    for record in manifest:
        path=here/record['mf_file']
        execution=json.loads((path.parent/'execution.json').read_text(encoding='utf-8'))
        assert execution['model_sha256']==file_digest(path),record['id']
        assert execution['solver_source_sha256']==solver_digest(),record['id']
    summaries.append(summary)
assert summaries[1]['static_pass']==summaries[1]['modal_pass']==150
combined={
    'model_count':sum(s['model_count'] for s in summaries),
    'static_pass':sum(s['static_pass'] for s in summaries),
    'modal_pass':sum(s['modal_pass'] for s in summaries),
    'new_batch':{'models':150,'static_pass':150,'modal_pass':150,
                 'static_success_rate':1.0,'modal_success_rate':1.0,
                 'analytical_static_checks':735,'analytical_modal_checks':95,
                 'named_assertions_run':300,'named_assertions_pass':300,
                 'schema_roundtrip_pass':150,'solver_process_failures':0},
    'total_named_assertions_pass':500,
    'solver_source_sha256':solver_digest(),
    'previous_batch_format_only_cache_refresh':'084_two_story_frame_v4: unchanged parsed JSON; current input retained and verification refreshed',
}
save_json(source/'combined_summary.json',combined)
files=[]
for path in source.rglob('*'):
    relative=path.relative_to(source)
    if not path.is_file() or any(part in ('work','__pycache__') for part in relative.parts) or path.suffix=='.pyc':
        continue
    destination=snapshot/relative
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(path,destination)
    files.append(relative)
note=root/'VALIDATION_STATUS.md'
note_text=note.read_text(encoding='utf-8').replace('](linear_modal/','](linear_modal_validation/').replace('](linear_modal_150/','](linear_modal_150_validation/')
(output/'VALIDATION_STATUS.md').write_text(note_text,encoding='utf-8')
# Refresh the original report snapshot after its formatting-only cache refresh.
old_snapshot=output/'linear_modal_validation'
for name in ('report.html','report.md','summary.json','summary.csv','verification_replay.log','run_history.json'):
    shutil.copy2(root/'linear_modal'/name,old_snapshot/name)
old_case='084_two_story_frame_v4'
for path in (root/'linear_modal'/'cases'/old_case).iterdir():
    if path.is_file():
        shutil.copy2(path,old_snapshot/'cases'/old_case/path.name)

archive=output/'linear_static_modal_150_new_models.zip'
shared_names=('__init__.py','models.py','reference.py','runner.py','reports.py','README.md','reference_audit.md')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for relative in files:
        z.write(snapshot/relative,Path('validation')/'linear_modal_150'/relative)
    for name in shared_names:
        z.write(root/'linear_modal'/name,Path('validation')/'linear_modal'/name)
    z.write(note,'validation/VALIDATION_STATUS.md')

class LinkAudit(HTMLParser):
    def __init__(self):
        super().__init__()
        self.rows=0
        self.links=[]
    def handle_starttag(self,tag,attrs):
        attributes=dict(attrs)
        if tag=='tr' and 'data-status' in attributes:
            self.rows+=1
        if tag=='a' and 'href' in attributes:
            self.links.append(attributes['href'])
parser=LinkAudit()
parser.feed((snapshot/'report.html').read_text(encoding='utf-8'))
assert parser.rows==150
assert all((snapshot/link).is_file() for link in parser.links)
assert len(list((snapshot/'cases').rglob('*.mf')))==150
assert len(list((snapshot/'cases').rglob('*_results.json')))==300
print('New batch exported:',len(files),'files;',parser.rows,'report rows and',len(parser.links),'links verified.')
print('New archive:',archive.stat().st_size,'bytes')
print('Combined totals:',combined['model_count'],combined['static_pass'],combined['modal_pass'])
