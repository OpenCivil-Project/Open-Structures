from validation.linear_modal_150.mass_support import build_cases
from validation.linear_modal.reference import analyze
from validation.linear_modal.runner import analytical_checks

failures=[]
count=0
cases=build_cases()
for case in cases:
    try:
        ref=analyze(case['model'],spec=case['spec'])
        data=ref['expected']
        checks=analytical_checks(data['static'],case['spec'],'static')+analytical_checks(
            {'tables':{'periods':[{'f':float(f)} for f in ref['frequencies_regularized']]}},case['spec'],'modal')
        count+=len(checks)
        bad=[c for c in checks if not c['passed']]
        if bad:
            failures.append((case['id'],bad))
    except Exception as error:
        failures.append((case['id'],repr(error)))
print('Cases',len(cases),'analytical checks',count,'failures',len(failures))
for item in failures:
    print(item)
