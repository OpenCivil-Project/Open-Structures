import json
from pathlib import Path

repo=Path('validation/linear_modal/cases/084_two_story_frame_v4/084_two_story_frame_v4.mf')
snapshot=Path(r'C:\Users\Ahmed\Documents\Codex\2026-11-03\go-to-e-metufire-opencivil-from\outputs\linear_modal_validation\cases\084_two_story_frame_v4\084_two_story_frame_v4.mf')
before=json.loads(snapshot.read_text(encoding='utf-8'))
after=json.loads(repo.read_text(encoding='utf-8'))
differences=[]
def visit(a,b,path=''):
    if isinstance(a,dict) and isinstance(b,dict):
        for key in sorted(set(a)|set(b)):
            if key not in a or key not in b:
                differences.append((path+'/'+key,'added/removed'))
            else:
                visit(a[key],b[key],path+'/'+key)
    elif isinstance(a,list) and isinstance(b,list):
        if len(a)!=len(b):
            differences.append((path,'length changed'))
        else:
            for i,(x,y) in enumerate(zip(a,b)):
                visit(x,y,path+'/'+str(i))
    elif a!=b:
        differences.append((path,str(a)[:80],str(b)[:80]))
visit(before,after)
print('Original case084 JSON changes:',len(differences))
for difference in differences[:30]:
    print(difference)
