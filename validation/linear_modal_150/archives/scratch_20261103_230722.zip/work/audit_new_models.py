"""Read-only semantic duplication and analytical-reference audit."""
import copy
import hashlib
import json
from pathlib import Path
from validation.linear_modal_150.models import build_cases
from validation.linear_modal_150.reference import analyze
from validation.linear_modal.runner import analytical_checks

def fingerprint(raw):
    nodes=sorted(raw['nodes'],key=lambda n:(n['x'],n['y'],n['z'],str(n['restraints'])))
    node_index={n['id']:i for i,n in enumerate(nodes)}
    material={m['name']:{key:value for key,value in m.items() if key!='name'} for m in raw['materials']}
    sections={}
    for s in raw['sections']:
        sections[s['name']]={key:value for key,value in s.items() if key not in ('name','mat_name','color')}
        sections[s['name']]['material']=material[s['mat_name']]
    elements=[]
    for e in raw['elements']:
        record={key:copy.deepcopy(value) for key,value in e.items() if key not in ('id','n1_id','n2_id','sec_name')}
        record.update(nodes=[node_index[e['n1_id']],node_index[e['n2_id']]],section=sections[e['sec_name']])
        elements.append((e['id'],record))
    elements.sort(key=lambda item:json.dumps(item[1],sort_keys=True))
    element_index={eid:i for i,(eid,_) in enumerate(elements)}
    loads=[]
    for record in raw['loads']:
        record=copy.deepcopy(record)
        if 'node_id' in record: record['node_id']=node_index[record['node_id']]
        if 'element_id' in record: record['element_id']=element_index[record['element_id']]
        loads.append(record)
    properties={p['name']:{key:value for key,value in p.items() if key!='name'} for p in raw.get('link_properties',[])}
    links=[]
    for link in raw.get('links',[]):
        entry={key:value for key,value in link.items() if key not in ('id','nodes','prop_name')}
        entry.update(nodes=[node_index[nid] for nid in link['nodes']],properties=properties[link['prop_name']])
        links.append(entry)
    sort=lambda sequence:sorted(sequence,key=lambda value:json.dumps(value,sort_keys=True))
    semantic=dict(active_dofs=raw['info']['active_dofs'],
        nodes=[{key:value for key,value in n.items() if key!='id'} for n in nodes],
        elements=[record for _,record in elements],loads=sort(loads),links=sort(links),
        load_patterns=sort(raw['load_patterns']),load_cases=sort(raw['load_cases']),mass_sources=sort(raw['mass_sources']))
    return hashlib.sha256(json.dumps(semantic,sort_keys=True).encode()).hexdigest()

folder=Path('validation/linear_modal_150').resolve()
old=Path('validation/linear_modal').resolve()
original=json.loads((old/'manifest.json').read_text())
old_signatures={fingerprint(json.loads((old/c['mf_file']).read_text())):c['id'] for c in original}
new=build_cases()
new_signatures={}
duplicates=[]
totals={'static':0,'modal':0}
failures=[]
min_free=10**9
min_frequency=float('inf')
for case in new:
    signature=fingerprint(case['model'])
    if signature in old_signatures: duplicates.append([case['id'],old_signatures[signature]])
    if signature in new_signatures: duplicates.append([case['id'],new_signatures[signature]])
    new_signatures[signature]=case['id']
    reference=analyze(case['model'],spec=case['spec'])
    data={'static':reference['expected']['static'],
          'modal':{'tables':{'periods':[{'f':float(f)} for f in reference['frequencies_regularized']]}}}
    for kind in ('static','modal'):
        checks=analytical_checks(data[kind],case['spec'],kind)
        totals[kind]+=len(checks)
        failures.extend([case['id'],check] for check in checks if not check['passed'])
    min_free=min(min_free,len(reference['free']))
    min_frequency=min(min_frequency,float(reference['frequencies_regularized'][0]))
report=dict(models=len(new),new_unique_fingerprints=len(new_signatures),duplicate_semantic_models=duplicates,
            analytical_check_counts=totals,analytical_reference_failures=failures,
            minimum_free_dofs=min_free,minimum_fundamental_hz=min_frequency)
(folder/'work'/'reference_audit_150.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
