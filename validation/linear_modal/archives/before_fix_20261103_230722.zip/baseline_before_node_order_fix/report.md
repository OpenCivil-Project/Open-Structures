# Linear static and modal verification

100 shared models; 98/100 static PASS; 98/100 modal PASS.

The reference is independent force-flexibility finite-element assembly. Continuum analytical comparisons are recorded separately in each expected.json. A numerical reference match alone does not establish convergence to continuum mechanics.

| Family | Models | Static pass | Modal pass |
|---|---:|---:|---:|
| cantilever_tip_y | 5 | 5 | 5 |
| cantilever_tip_z | 5 | 5 | 5 |
| inclined_cantilever | 5 | 4 | 4 |
| cantilever_udl | 5 | 5 | 5 |
| cantilever_tip_moment | 5 | 5 | 5 |
| axial_bar | 5 | 5 | 5 |
| torsion_bar | 5 | 5 | 5 |
| simply_supported_point | 5 | 5 | 5 |
| simply_supported_udl | 5 | 5 | 5 |
| fixed_fixed_point | 5 | 5 | 5 |
| fixed_fixed_udl | 5 | 5 | 5 |
| propped_udl | 5 | 5 | 5 |
| continuous_two_span | 5 | 5 | 5 |
| rigid_portal | 5 | 5 | 5 |
| pinned_base_portal | 5 | 5 | 5 |
| released_beam_portal | 5 | 5 | 5 |
| two_story_frame | 5 | 4 | 4 |
| space_frame | 5 | 5 | 5 |
| stepped_axial_chain | 5 | 5 | 5 |
| elastic_support_beam | 5 | 5 | 5 |

Failing cases:

- [015_inclined_cantilever_v5](cases/015_inclined_cantilever_v5/comparison.json): static: nodal displacement and rotation, support force and moment, independent free-DOF equilibrium residual, analytical: Inclined tip displacement, analytical: Inclined tip displacement, analytical: Inclined tip displacement, analytical: Inclined tip rotation, analytical: Inclined tip rotation, analytical: Inclined tip rotation; modal: maximum relative frequency error, maximum independent eigen residual, worst modal subspace mismatch (1-MAC)
- [085_two_story_frame_v5](cases/085_two_story_frame_v5/comparison.json): static: nodal displacement and rotation, support force and moment, independent free-DOF equilibrium residual; modal: maximum relative frequency error, maximum independent eigen residual, worst modal subspace mismatch (1-MAC)

Runtime: 164.8 seconds. Python 3.12.8, NumPy 1.26.4, SciPy 1.17.0.
Git commit: ebc58545120353886dc9c2cc91f45db93d409000. See summary.json for exact checks and tolerances.

Prior execution failures preserved:

- 100_elastic_support_beam_v5: [{'returncode': 3221226505}]; subsequent targeted rerun completed. See execution.json and run_history.json.
