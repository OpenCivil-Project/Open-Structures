import json
from pathlib import Path
from validation.linear_modal.runner import compare, file_digest, save_json, solver_digest, run_one
from validation.linear_modal.reference import analyze
from validation.linear_modal.reports import write_reports

here=Path('validation/linear_modal').resolve()
manifest=json.loads((here/'manifest.json').read_text(encoding='utf-8'))
initial=json.loads((here/'summary.json').read_text(encoding='utf-8'))
save_json(here/'run_history.json',{
    'initial_run':{key:initial[key] for key in ('model_count','static_pass','static_fail','modal_pass','modal_fail','elapsed_seconds','environment')},
    'initial_failures':[r['id'] for r in initial['cases'] if not r['static']['passed'] or not r['modal']['passed']],
    'targeted_retry':{'id':manifest[-1]['id'],'initial_returncode':3221226505,'subsequent_returncode':0,
                      'reason':'Windows process fast-fail, no results produced; isolated retry succeeded.'},
    'provenance_note':'Production solver source remained unchanged during the initial sweep. Initial model/source hashes were captured after that sweep; later runner executions capture them before solving.'})
results=[]
for record in manifest:
    path=here/record['mf_file']
    ep=path.parent/'execution.json'
    execution=json.loads(ep.read_text(encoding='utf-8'))
    if 'model_sha256' not in execution:
        execution.update(model_sha256=file_digest(path),solver_source_sha256=solver_digest(),provenance_captured_after_initial_run=True)
        save_json(ep,execution)
    case={**record,'mf_path':path,'directory':path.parent,'model':json.loads(path.read_text(encoding='utf-8'))}
    result=compare(case,analyze(case['model'],spec=record.get('spec')))
    save_json(path.parent/'comparison.json',result)
    results.append(result)
write_reports(here,results,initial['elapsed_seconds']+3.84)
print('Final static/modal passes:',sum(r['static']['passed'] for r in results),sum(r['modal']['passed'] for r in results))

probe=here/'work'/'node_order_probe'
probe.mkdir(parents=True,exist_ok=True)
probes=[]
for record in manifest:
    if record['id'] not in ('015_inclined_cantilever_v5','085_two_story_frame_v5'):
        continue
    original=here/record['mf_file']
    raw=json.loads(original.read_text(encoding='utf-8'))
    raw['nodes'].sort(key=lambda n:n['id'])
    folder=probe/record['id']
    folder.mkdir(parents=True,exist_ok=True)
    path=folder/(record['id']+'_sorted.mf')
    save_json(path,raw)
    case={**record,'mf_path':path,'directory':folder,'model':raw}
    save_json(folder/'execution.json',run_one(case,90))
    result=compare(case,analyze(raw,spec=record.get('spec')))
    save_json(folder/'comparison.json',result)
    probes.append(result)
    print('Sorted-record control:',record['id'],result['static']['passed'],result['modal']['passed'])
save_json(here/'node_order_controls.json',probes)
