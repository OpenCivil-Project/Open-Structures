import json
from pathlib import Path
from validation.linear_modal.runner import file_digest, save_json, solver_digest

here=Path('validation/linear_modal').resolve()
summary=json.loads((here/'summary.json').read_text(encoding='utf-8'))
assert summary['model_count']==summary['static_pass']==summary['modal_pass']==100
assert not summary['execution_warnings']
unchanged={}
for cid in ('015_inclined_cantilever_v5','085_two_story_frame_v5'):
    current=here/'cases'/cid/(cid+'.mf')
    previous=here/'baseline_before_node_order_fix'/'cases'/cid/(cid+'.mf')
    unchanged[cid]=file_digest(current)==file_digest(previous)
assert all(unchanged.values())
history=json.loads((here/'run_history.json').read_text(encoding='utf-8'))
baseline=json.loads((here/'baseline_before_node_order_fix'/'summary.json').read_text(encoding='utf-8'))
history['stable_pre_fix_baseline']={key:baseline[key] for key in ('model_count','static_pass','static_fail','modal_pass','modal_fail')}
history['post_node_order_fix']={key:summary[key] for key in ('model_count','static_pass','static_fail','modal_pass','modal_fail','elapsed_seconds','environment')}
history['post_node_order_fix'].update(
    fix='DataManager initial node list sorted by ID to match existing sorted DOF indices',
    solver_source_sha256=solver_digest(),
    regression_inputs_unchanged=unchanged,
    numerical_assertions={'run':200,'passed':200},
    focused_regression_tests={'run':4,'passed':4},
    process_failures=0)
save_json(here/'run_history.json',history)
print('History updated; both shuffled regression inputs are byte-for-byte unchanged.')
