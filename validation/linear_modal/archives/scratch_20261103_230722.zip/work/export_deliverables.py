from html.parser import HTMLParser
from pathlib import Path
import shutil
import subprocess
import zipfile

source=Path('validation/linear_modal').resolve()
output=Path(r'C:\Users\Ahmed\Documents\Codex\2026-11-03\go-to-e-metufire-opencivil-from\outputs')
output.mkdir(parents=True,exist_ok=True)
snapshot=output/'linear_modal_validation'
snapshot.mkdir(parents=True,exist_ok=True)
files=[]
for path in source.rglob('*'):
    relative=path.relative_to(source)
    if not path.is_file() or any(part in ('work','__pycache__') for part in relative.parts) or path.suffix=='.pyc':
        continue
    destination=snapshot/relative
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(path,destination)
    files.append(relative)
note=source.parent/'VALIDATION_STATUS.md'
note_text=note.read_text(encoding='utf-8').replace('](linear_modal/','](linear_modal_validation/')
(output/'VALIDATION_STATUS.md').write_text(note_text,encoding='utf-8')
shutil.copy2(note,snapshot/'VALIDATION_STATUS.md')
test_source=source.parents[1]/'tests'/'test_solver_node_order.py'
shutil.copy2(test_source,output/'test_solver_node_order.py')
patch=subprocess.check_output(['git','diff','--','core/solver/linear_static/data_manager.py'],cwd=source.parents[1])
(output/'node_order_fix.patch').write_bytes(patch)
archive=output/'linear_static_modal_100_models.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for relative in files:
        z.write(snapshot/relative,Path('linear_modal')/relative)
    z.write(note,'validation/VALIDATION_STATUS.md')
    z.write(test_source,'tests/test_solver_node_order.py')
    z.writestr('node_order_fix.patch',patch)

class CheckLinks(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links=[]
        self.cases=0
    def handle_starttag(self,tag,attrs):
        attributes=dict(attrs)
        if tag=='a' and 'href' in attributes:
            self.links.append(attributes['href'])
        if tag=='tr' and 'data-status' in attributes:
            self.cases+=1
parser=CheckLinks()
parser.feed((snapshot/'report.html').read_text(encoding='utf-8'))
assert parser.cases==100
missing=[link for link in parser.links if not (snapshot/link).is_file()]
assert not missing,missing
assert len(list((snapshot/'cases').rglob('*.mf')))==100
assert len(list((snapshot/'cases').rglob('*_results.json')))==200
print('Exported',len(files),'files; report100rows and',len(parser.links),'links verified.')
print('Archive:',archive,'bytes:',archive.stat().st_size)
